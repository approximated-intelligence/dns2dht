from twisted.names.dns import QUERY_TYPES, EXT_QUERIES
ALL_TYPES = dict(QUERY_TYPES.items() + EXT_QUERIES.items())
